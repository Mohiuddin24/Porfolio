import { Github, Linkedin, Facebook, Instagram, Globe } from "lucide-react";

export const SOCIAL_LINKS = [
  {
    href: "https://github.com/Mohiuddin24",
    icon: Github,
    label: "GitHub",
  },
  {
    href: "https://www.linkedin.com/in/mohiuddin-khan-rabbi-856292181",
    icon: Linkedin,
    label: "LinkedIn",
  },
  {
    href: "https://www.facebook.com/share/18q9cgFxd2/",
    icon: Facebook,
    label: "Facebook",
  },
  {
    href: "https://www.instagram.com/mohiuddin.2019",
    icon: Instagram,
    label: "Instagram",
  },
  {
    href: "https://g.page/r/CdXTVkP0xVG9EBI/review",
    icon: Globe,
    label: "Google Business",
  },
] as const;