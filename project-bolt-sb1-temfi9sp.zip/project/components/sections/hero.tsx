"use client";

import { TypeAnimation } from "react-type-animation";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { 
  Github, 
  Linkedin, 
  Facebook, 
  Instagram, 
  Globe 
} from "lucide-react";

export function HeroSection() {
  const socialLinks = [
    {
      href: "https://github.com/Mohiuddin24",
      icon: Github,
      label: "GitHub",
    },
    {
      href: "https://www.linkedin.com/in/mohiuddin-khan-rabbi-856292181",
      icon: Linkedin,
      label: "LinkedIn",
    },
    {
      href: "https://www.facebook.com/share/18q9cgFxd2/",
      icon: Facebook,
      label: "Facebook",
    },
    {
      href: "https://www.instagram.com/mohiuddin.2019",
      icon: Instagram,
      label: "Instagram",
    },
    {
      href: "https://g.page/r/CdXTVkP0xVG9EBI/review",
      icon: Globe,
      label: "Google Business",
    },
  ];

  return (
    <section className="min-h-screen pt-16 flex items-center">
      <div className="container mx-auto px-4">
        <div className="flex flex-col-reverse md:flex-row items-center justify-between gap-8">
          <motion.div 
            className="flex-1"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-4">
              Hi, I'm Mohiuddin Khan Rabbi
            </h1>
            <div className="text-xl md:text-2xl text-muted-foreground mb-6">
              <TypeAnimation
                sequence={[
                  "JavaScript Developer",
                  1000,
                  "MERN Stack Learner",
                  1000,
                  "Digital Marketer",
                  1000,
                  "AI Enthusiast",
                  1000,
                ]}
                wrapper="span"
                speed={50}
                repeat={Infinity}
              />
            </div>
            <div className="flex gap-4 mb-8">
              {socialLinks.map((link) => (
                <motion.a
                  key={link.label}
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-muted-foreground hover:text-foreground transition-colors"
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <link.icon className="h-6 w-6" />
                  <span className="sr-only">{link.label}</span>
                </motion.a>
              ))}
            </div>
            <Button size="lg">
              Download CV
            </Button>
          </motion.div>
          <motion.div 
            className="flex-1 flex justify-center"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="relative w-64 h-64 md:w-96 md:h-96 rounded-full overflow-hidden">
              <img
                src="https://imgur.com/gallery/igigigib0v-SUEY6vC"
                alt="Mohiuddin Khan Rabbi"
                className="object-cover w-full h-full"
              />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}