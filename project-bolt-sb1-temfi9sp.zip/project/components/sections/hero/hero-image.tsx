"use client";

import { motion } from "framer-motion";
import Image from "next/image";

export function HeroImage() {
  return (
    <motion.div 
      className="flex-1 flex justify-center"
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="relative w-64 h-64 md:w-96 md:h-96 rounded-full overflow-hidden">
        <Image
          src="https://postimg.cc/ppLG4f35"
          alt="Mohiuddin Khan Rabbi"
          fill
          className="object-cover"
          priority
        />
      </div>
    </motion.div>
  );
}