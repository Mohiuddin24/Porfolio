"use client";

import { motion } from "framer-motion";
import { HeroContent } from "./hero-content";
import { HeroImage } from "./hero-image";

export function HeroSection() {
  return (
    <section className="min-h-screen pt-16 flex items-center">
      <div className="container mx-auto px-4">
        <div className="flex flex-col-reverse md:flex-row items-center justify-between gap-8">
          <HeroContent />
          <HeroImage />
        </div>
      </div>
    </section>
  );
}