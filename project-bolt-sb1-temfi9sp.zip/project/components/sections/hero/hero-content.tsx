"use client";

import { motion } from "framer-motion";
import { TypeAnimation } from "react-type-animation";
import { Button } from "@/components/ui/button";
import { SocialLinks } from "./social-links";

export function HeroContent() {
  return (
    <motion.div 
      className="flex-1"
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h1 className="text-4xl md:text-6xl font-bold mb-4">
        Hi, I'm Mohiuddin Khan Rabbi
      </h1>
      <div className="text-xl md:text-2xl text-muted-foreground mb-6">
        <TypeAnimation
          sequence={[
            "JavaScript Developer",
            1000,
            "MERN Stack Learner",
            1000,
            "Digital Marketer",
            1000,
            "AI Enthusiast",
            1000,
          ]}
          wrapper="span"
          speed={50}
          repeat={Infinity}
        />
      </div>
      <SocialLinks />
      <Button size="lg">
        Download CV
      </Button>
    </motion.div>
  );
}