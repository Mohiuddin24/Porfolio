"use client";

import { motion } from "framer-motion";
import { Github, Linkedin, Facebook, Instagram, Globe } from "lucide-react";
import { SOCIAL_LINKS } from "@/config/social-links";

export function SocialLinks() {
  return (
    <div className="flex gap-4 mb-8">
      {SOCIAL_LINKS.map((link) => (
        <motion.a
          key={link.label}
          href={link.href}
          target="_blank"
          rel="noopener noreferrer"
          className="text-muted-foreground hover:text-foreground transition-colors"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.95 }}
        >
          <SocialIcon icon={link.icon} />
          <span className="sr-only">{link.label}</span>
        </motion.a>
      ))}
    </div>
  );
}

function SocialIcon({ icon: Icon }) {
  return <Icon className="h-6 w-6" />;
}